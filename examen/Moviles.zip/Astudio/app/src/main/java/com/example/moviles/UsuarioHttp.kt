package com.example.moviles

import java.util.*

internal class UsuarioHttp (
var id: Int,
var createdAt: Long,
var updateAt: Long,
var cedula: String ,
var nombre: String,
var correo: String,
var estadoCivil: String,
var password: String
){
    var fechaCreacin: Date
    var fechaActualizacion: Date

    init{
        fechaCreacin= Date(createdAt)
        fechaActualizacion= Date(updateAt)
    }
}
