package com.example.moviles

class RecyclerAdaptador(
    private var listaUsuarios:List<UsuarioHttp>,
    private val recyclerView:RecyclerView):
{
}