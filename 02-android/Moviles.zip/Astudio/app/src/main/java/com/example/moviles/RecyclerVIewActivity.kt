package com.example.moviles

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RecyclerVIewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycler_v_iew)
    }
}